﻿using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetArjunTakeHomeAssignment
{
    public class CommonUtility
    {
        /// <summary>
        /// This is enum.
        /// </summary>
        public enum GuestType
        {
            Normal = 1,
            VIP,
            SpecialVIP
        }

        /// <summary>
        /// this will be used for logging.
        /// </summary>
        public static ILogger SeriLogger { get; set; }

    }

    /// <summary>
    /// This is a common response model format standard created to use.
    /// </summary>
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }
        public dynamic Data { get; set; }
        public string ErrorMessage { get; set; }
    }

    public static class Constants
    {
        #region Error Messages
        public const string Error_Message_Guest = "Guest input value missing.";
        public const string Error_Message_GuestID = "Please provide guestId.";
        public const string Error_Message_GuestMissing = "Guest not available.";
        public const string Error_Message_Name = "Please provide first name or last name.";
        public const string Error_Message_PhoneNo = "Please provide atleast one phone number.";
        public const string Error_Message_PhoneNoExists = "Phone number already exists.";
        #endregion

        #region Success Messages
        public const string Success_Message_Guest = "Guest added successfully.";
        public const string Success_Message_Phone = "Phone number added successfully.";
        #endregion
    }
}
