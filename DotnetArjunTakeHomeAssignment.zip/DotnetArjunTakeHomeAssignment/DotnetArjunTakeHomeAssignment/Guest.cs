using System;
using System.ComponentModel.DataAnnotations.Schema;
using static DotnetArjunTakeHomeAssignment.CommonUtility;

namespace DotnetArjunTakeHomeAssignment
{
    /// <summary>
    /// This is a data model to pass the data.
    /// </summary>
    public class GuestModel
    {
        public Guid Id { get; set; }
        public GuestType Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public string Email { get; set; }
        [NotMapped]
        public string[] PhoneNumbers { get; set; }
    }
}
