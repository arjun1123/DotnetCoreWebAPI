﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using static DotnetArjunTakeHomeAssignment.CommonUtility;
using DotnetArjunTakeHomeAssignment.Data;

namespace DotnetArjunTakeHomeAssignment.Controllers
{
    [ApiController]
    [Route("Guest")]
    public class GuestController : ControllerBase
    {
        private readonly MyDBContext _dBContext;
        public GuestController(MyDBContext myDBContext)
        {
            _dBContext = myDBContext;
        }

        [HttpPost]
        [Route("/AddGuest")]
        public ResponseModel AddGuest(GuestModel guest)
        {
            SeriLogger.Information("AddGuest - {0}", new { LogInputInfo = guest, RequestedDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss") });
            ResponseModel objResponse = new ResponseModel();
            try
            {
                if (guest == null)
                {
                    objResponse.IsSuccess = false;
                    objResponse.ErrorMessage = Constants.Error_Message_Guest;
                    return objResponse;
                }
                else if (string.IsNullOrEmpty(guest.FirstName + guest.LastName))
                {
                    objResponse.IsSuccess = false;
                    objResponse.ErrorMessage = Constants.Error_Message_Name;
                    return objResponse;
                }
                else if (guest.PhoneNumbers == null || guest.PhoneNumbers.Length == 0)
                {
                    objResponse.IsSuccess = false;
                    objResponse.ErrorMessage = Constants.Error_Message_PhoneNo;
                    return objResponse;
                }
                _dBContext.Add(guest);
                _dBContext.SaveChanges();
                objResponse.Data = Constants.Success_Message_Guest;
                objResponse.IsSuccess = true;
            }
            catch (Exception exc)
            {
                SeriLogger.Error("AddGuest API Error - {0}", exc.Message);
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = exc.Message;
            }
            return objResponse;
        }
        [HttpPost]
        [Route("/AddPhoneNo")]
        public ResponseModel AddPhoneNo(string guestId, string phoneNumber)
        {
            SeriLogger.Information("AddPhoneNo - {0}", new { LogInputInfo = phoneNumber, RequestedDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss") });
            ResponseModel objResponse = new ResponseModel();
            if (string.IsNullOrEmpty(guestId))
            {
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = Constants.Error_Message_GuestID;
                return objResponse;
            }
            if (string.IsNullOrEmpty(phoneNumber))
            {
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = "Please provide phoneNumber.";
                return objResponse;
            }
            try
            {
                Guid gustId = Guid.Parse(guestId);
                var guest = _dBContext.Guests
                    .FirstOrDefault(m => m.Id == gustId);
                if (guest == null)
                {
                    objResponse.IsSuccess = false;
                    objResponse.ErrorMessage = Constants.Error_Message_GuestMissing;
                    return objResponse;
                }
                foreach (var item in guest.PhoneNumbers)
                {
                    if (item.Equals(phoneNumber))
                    {
                        objResponse.IsSuccess = false;
                        objResponse.ErrorMessage = Constants.Error_Message_PhoneNoExists;
                        return objResponse;
                    }
                }
                guest.PhoneNumbers = guest.PhoneNumbers.Append(phoneNumber).ToArray();
                _dBContext.SaveChanges();
                objResponse.Data = Constants.Success_Message_Phone;
                objResponse.IsSuccess = true;
            }
            catch (Exception exc)
            {
                SeriLogger.Error("AddPhoneNo API Error - {0}", exc.Message);
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = exc.Message;
            }
            return objResponse;
        }
        [HttpGet]
        [Route("/GetGuestById")]
        public ResponseModel GetGuestById(string guestId)
        {
            SeriLogger.Information("GetGuestById - {0}", new { LogInputInfo = guestId, RequestedDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss") });
            ResponseModel objResponse = new ResponseModel();
            if (string.IsNullOrEmpty(guestId))
            {
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = Constants.Error_Message_GuestID;
                return objResponse;
            }
            try
            {
                Guid gustId = Guid.Parse(guestId);
                var guest = _dBContext.Guests
                    .FirstOrDefault(m => m.Id == gustId);
                if (guest == null)
                {
                    objResponse.IsSuccess = false;
                    objResponse.ErrorMessage = Constants.Error_Message_GuestMissing;
                    return objResponse;
                }
                objResponse.Data = guest;
                objResponse.IsSuccess = true;
            }
            catch (Exception exc)
            {
                SeriLogger.Error("GetGuestById API Error - {0}", exc.Message);
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = exc.Message;
            }
            return objResponse;
        }
        [HttpGet]
        [Route("/GetAllGuests")]
        public ResponseModel GetAllGuests()
        {
            SeriLogger.Information("GetAllGuests - {0}", new { RequestedDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss") });
            ResponseModel objResponse = new ResponseModel();
            try
            {
                AddDummyData();
                objResponse.Data = _dBContext.Guests.ToList();
                objResponse.IsSuccess = true;
            }
            catch (Exception exc)
            {
                SeriLogger.Error("GetAllGuests API Error - {0}", exc.Message);
                objResponse.IsSuccess = false;
                objResponse.ErrorMessage = exc.Message;
            }
            return objResponse;
        }

        /// <summary>
        /// AddDummyData method
        /// </summary>
        private void AddDummyData()
        {
            #region Adding some dummy guests data to display
            try
            {
                if (_dBContext.Guests.ToList().Count == 0)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        _dBContext.Add(new DotnetArjunTakeHomeAssignment.GuestModel()
                        {
                            Id = Guid.NewGuid(),
                            FirstName = "Arjun" + new Random().Next(),
                            LastName = "Dubey" + new Random().Next(),
                            Email = "testard28@gmail.com",
                            BirthDate = DateTime.Now.Date,
                            PhoneNumbers = new string[] { Convert.ToString(new Random().Next(999999999)), Convert.ToString(new Random().Next(999999999)) },
                            Title = GuestType.Normal
                        });
                    }
                }
                _dBContext.SaveChanges();
            }
            catch (Exception exc)
            {
                SeriLogger.Error("AddDummyData() Error - {0}", exc.Message);
            }
            #endregion
        }
    }
}
