﻿using Microsoft.EntityFrameworkCore;

namespace DotnetArjunTakeHomeAssignment.Data
{
    /// <summary>
    /// This is custom dbContext class created to perform all add/update/delete operations
    /// </summary>
    public class MyDBContext : DbContext
    {
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {
            
        }
        /// <summary>
        /// Guests in memory db set entity
        /// </summary>
        public DbSet<GuestModel> Guests { get; set; }
    }
}
